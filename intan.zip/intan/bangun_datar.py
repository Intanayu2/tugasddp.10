import math 

def luas_persegi(s):
    return s * s
    
def luas_lingkaran(r):
    return math.pi + (r ** 2)

def luas_segitiga(a, t):
    return (a * t)/ 2

def luas_persegi_panjang(p, l):
    return p * l

def luas_trapesium(a, b, t):
    return ((a + b) * t) / 2
    
    
    
