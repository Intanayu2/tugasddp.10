from math import *

def luas_balok(p, l, t):
    return 2 * ((p*l)+(p*t)+(l*t))
def luas_kubus(s):
    return 6 * s**2
def luas_tabung(r, t):
    return 2 * pi * r * (r + t)
def luas_kerucut(r ,s):
    return pi * r * (r+s)
def luas_bola(r):
    return 4 * pi * r**2

